package ddwu.mobile.finalproject.ma02_20190999.library;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import ddwu.mobile.finalproject.ma02_20190999.R;

public class ListInfoLibrary extends AppCompatActivity {
//    String address;
    String libAddress;
    ArrayList<libraryDto> skiResultList;
    String mapx; //메인에서 받아온 스키장의 경도
    String mapy; //메인에서 받아온 스키장의 위도
//    String skiContentId;
    libraryDto select;
    TextView libName;
    TextView op_top;
    TextView op_name_tv;
    TextView op_ctp_tv;
    TextView op_close_tv;
    TextView op_road_tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.library_info);

        libName = (TextView)findViewById(R.id.skiName);
        op_top = (TextView)findViewById(R.id.op_top);
        op_name_tv = (TextView)findViewById(R.id.op_add_tv);//lbrryNm; //도서관명
        op_ctp_tv = (TextView)findViewById(R.id.op_tel_tv);//시도명
        op_close_tv = (TextView)findViewById(R.id.op_info_tv);//휴관일
        op_road_tv = (TextView)findViewById(R.id.op_open_tv);//rdnmadr; //소새지도로명주소

        Intent intent = getIntent();
//        skiContentId = intent.getStringExtra("skiId");
        select = (libraryDto) intent.getSerializableExtra("selectList"); //용평이면 용평의 title,
        libName.setText(select.getLbrryNm());

//        mapx = select.getMapX();
//        mapy = select.getMapY();
//        skiResultList = new ArrayList();

        libAddress = getResources().getString(R.string.common_info);
        libAddress += skiContentId;
        new skiNetworkAsyncTask().execute(libAddress);

        resultList = new ArrayList();
        address = getResources().getString(R.string.server_rental_url);
        address += mapx + "&mapY=" + mapy;


        new NetworkAsyncTask().execute(address);

    }

    class NetworkAsyncTask extends AsyncTask<String, Integer, String> {
        public final static String TAG = "NetworkAsyncTask";
        public final static int TIME_OUT = 10000;
        ProgressDialog progressDlg;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDlg = ProgressDialog.show(ListInfoLibrary.this, "스키장 찾는 중...", "Downloading...");     // 진행상황 다이얼로그 출력
        }
        @Override
        protected String doInBackground(String... strings) {
            String address = strings[0];
            StringBuilder result = new StringBuilder();
            BufferedReader br = null;
            HttpURLConnection conn = null;

            try {
                URL url = new URL(address);
                conn = (HttpURLConnection) url.openConnection();

                if (conn != null) {
                    conn.setConnectTimeout(TIME_OUT);
                    conn.setUseCaches(false);
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                        for (String line = br.readLine(); line != null; line = br.readLine()) {
                            result.append(line + '\n');
                        }
                    }
                }

            } catch (MalformedURLException ex) {
                ex.printStackTrace();
                cancel(false);
            } catch (Exception ex) {
                ex.printStackTrace();
                cancel(false);
            } finally {
                try {
                    if (br != null) br.close();
                    if (conn != null) conn.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return result.toString();
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
            Toast.makeText(ListInfoLibrary.this, "Error!!!", Toast.LENGTH_SHORT).show();
            progressDlg.dismiss();
        }
    }

    class skiNetworkAsyncTask extends AsyncTask<String, Integer, String> {
        public final static String TAG = "NetworkAsyncTask";
        public final static int TIME_OUT = 10000;
        ProgressDialog progressDlg;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDlg = ProgressDialog.show(ListInfoLibrary.this, "Wait", "Downloading...");     // 진행상황 다이얼로그 출력
        }
        @Override
        protected String doInBackground(String... strings) {
            String address = strings[0];
            StringBuilder result = new StringBuilder();
            BufferedReader br = null;
            HttpURLConnection conn = null;

            try {
                URL url = new URL(address);
                conn = (HttpURLConnection) url.openConnection();

                if (conn != null) {
                    conn.setConnectTimeout(TIME_OUT);
                    conn.setUseCaches(false);
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                        for (String line = br.readLine(); line != null; line = br.readLine()) {
                            result.append(line + '\n');
                        }
                    }
                }

            } catch (MalformedURLException ex) {
                ex.printStackTrace();
                cancel(false);
            } catch (Exception ex) {
                ex.printStackTrace();
                cancel(false);
            } finally {
                try {
                    if (br != null) br.close();
                    if (conn != null) conn.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return result.toString();
        }
        @Override
        protected void onPostExecute(String result) {
            libraryXmlparser parser = new libraryXmlparser();
            skiResultList = parser.parse(result);
            op_top.setText(skiResultList.get(0).getTitle() + "에 놀러오세요~!\n");
            op_name_tv.setText(skiResultList.get(0).getAddress());
            op_ctp_tv.setText(select.getTel());
            op_close_tv.setText(skiResultList.get(0).getOverview());
            alarmMonth = skiResultList.get(0).getOverview().substring(0, 2);
            alarmDay = skiResultList.get(0).getOverview().substring(3,5);
            if(alarmDay.contains("일")) {
                alarmDay = skiResultList.get(0).getOverview().substring(3,4);
            }


            if (skiResultList.get(0).getOverview().substring(0, 6).contains("월"))
                op_road_tv.setText(skiResultList.get(0).getOverview().substring(0, 6));
            else
                op_road_tv.setText("홈페이지 참고");
            progressDlg.dismiss();
        }


        @Override
        protected void onCancelled() {
            super.onCancelled();
            Toast.makeText(ListInfoLibrary.this, "Error!!!", Toast.LENGTH_SHORT).show();
            progressDlg.dismiss();
        }
    }
}
